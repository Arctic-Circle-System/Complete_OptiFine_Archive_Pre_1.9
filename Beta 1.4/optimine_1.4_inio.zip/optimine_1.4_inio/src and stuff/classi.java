// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   h.java

import java.nio.IntBuffer;
import java.util.*;
import net.minecraft.client.Minecraft;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.ARBOcclusionQuery;
import org.lwjgl.opengl.GL11;

public class classi
    implements mo
{

    public classi(Minecraft minecraft, ho var2)
    {
        a = new ArrayList();
        m = new ArrayList();
        w = false;
        x = 0;
        H = -1;
        I = 2;
        b = new int[50000];
        c = ez.c(64);
        chunkLists = BufferUtils.createIntBuffer(0x10000);
        d = 0;
        e = ez.a(1);
        f = -9999D;
        g = -9999D;
        h = -9999D;
        j = 0;
        t = minecraft;
        l = var2;
        byte var3 = 64;
        s = ez.a(var3 * var3 * var3 * 3);
        w = minecraft.m().a();
        if(w)
        {
            c.clear();
            v = ez.c(var3 * var3 * var3);
            v.clear();
            v.position(0);
            v.limit(var3 * var3 * var3);
            ARBOcclusionQuery.glGenQueriesARB(v);
        }
        y = ez.a(3);
        GL11.glPushMatrix();
        GL11.glNewList(y, 4864);
        f();
        GL11.glEndList();
        GL11.glPopMatrix();
        lj var4 = lj.a;
        z = y + 1;
        GL11.glNewList(z, 4864);
        byte var6 = 64;
        int var7 = 256 / var6 + 2;
        float var5 = 16F;
        for(int var8 = -var6 * var7; var8 <= var6 * var7; var8 += var6)
        {
            for(int var9 = -var6 * var7; var9 <= var6 * var7; var9 += var6)
            {
                var4.b();
                var4.a(var8 + 0, var5, var9 + 0);
                var4.a(var8 + var6, var5, var9 + 0);
                var4.a(var8 + var6, var5, var9 + var6);
                var4.a(var8 + 0, var5, var9 + var6);
                var4.a();
            }

        }

        GL11.glEndList();
        A = y + 2;
        GL11.glNewList(A, 4864);
        var5 = -16F;
        var4.b();
        for(int i1 = -var6 * var7; i1 <= var6 * var7; i1 += var6)
        {
            for(int var9 = -var6 * var7; var9 <= var6 * var7; var9 += var6)
            {
                var4.a(i1 + var6, var5, var9 + 0);
                var4.a(i1 + 0, var5, var9 + 0);
                var4.a(i1 + 0, var5, var9 + var6);
                var4.a(i1 + var6, var5, var9 + var6);
            }

        }

        var4.a();
        GL11.glEndList();
    }

    private void f()
    {
        Random var1 = new Random(10842L);
        lj var2 = lj.a;
        var2.b();
        for(int var3 = 0; var3 < 1500; var3++)
        {
            double var4 = var1.nextFloat() * 2.0F - 1.0F;
            double var6 = var1.nextFloat() * 2.0F - 1.0F;
            double var8 = var1.nextFloat() * 2.0F - 1.0F;
            double var10 = 0.25F + var1.nextFloat() * 0.25F;
            double var12 = var4 * var4 + var6 * var6 + var8 * var8;
            if(var12 >= 1.0D || var12 <= 0.01D)
                continue;
            var12 = 1.0D / Math.sqrt(var12);
            var4 *= var12;
            var6 *= var12;
            var8 *= var12;
            double var14 = var4 * 100D;
            double var16 = var6 * 100D;
            double var18 = var8 * 100D;
            double var20 = Math.atan2(var4, var8);
            double var22 = Math.sin(var20);
            double var24 = Math.cos(var20);
            double var26 = Math.atan2(Math.sqrt(var4 * var4 + var8 * var8), var6);
            double var28 = Math.sin(var26);
            double var30 = Math.cos(var26);
            double var32 = var1.nextDouble() * 3.1415926535897931D * 2D;
            double var34 = Math.sin(var32);
            double var36 = Math.cos(var32);
            for(int var38 = 0; var38 < 4; var38++)
            {
                double var39 = 0.0D;
                double var41 = (double)((var38 & 2) - 1) * var10;
                double var43 = (double)((var38 + 1 & 2) - 1) * var10;
                double var47 = var41 * var36 - var43 * var34;
                double var49 = var43 * var36 + var41 * var34;
                double var53 = var47 * var28 + var39 * var30;
                double var55 = var39 * var28 - var47 * var30;
                double var57 = var55 * var22 - var49 * var24;
                double var61 = var49 * var22 + var55 * var24;
                var2.a(var14 + var57, var16 + var53, var18 + var61);
            }

        }

        var2.a();
    }

    public void a(eb eb1)
    {
        if(k != null)
            k.b(this);
        f = -9999D;
        g = -9999D;
        h = -9999D;
        ps.a.a(eb1);
        k = eb1;
        u = new ca(eb1);
        if(eb1 != null)
        {
            eb1.a(this);
            a();
        }
    }

    public void a()
    {
        ra.K.a(t.y.i);
        H = t.y.e;
        int var1;
        if(o != null)
            for(var1 = 0; var1 < o.length; var1++)
                o[var1].c();

        var1 = 64 << 3 - H;
        if(var1 > 400)
            var1 = 400;
        p = var1 / 16 + 1;
        q = 8;
        r = var1 / 16 + 1;
        o = new cp[p * q * r];
        n = new cp[p * q * r];
        int var2 = 0;
        int var3 = 0;
        B = 0;
        C = 0;
        D = 0;
        E = p;
        F = q;
        G = r;
        for(int var4 = 0; var4 < m.size(); var4++)
            ((cp)m.get(var4)).u = false;

        m.clear();
        a.clear();
        for(int i1 = 0; i1 < p; i1++)
        {
            for(int var5 = 0; var5 < q; var5++)
            {
                for(int var6 = 0; var6 < r; var6++)
                {
                    o[(var6 * q + var5) * p + i1] = new cp(k, a, i1 * 16, var5 * 16, var6 * 16, 16, s + var2);
                    if(w)
                        o[(var6 * q + var5) * p + i1].z = v.get(var3);
                    o[(var6 * q + var5) * p + i1].y = false;
                    o[(var6 * q + var5) * p + i1].x = true;
                    o[(var6 * q + var5) * p + i1].o = true;
                    o[(var6 * q + var5) * p + i1].w = var3++;
                    o[(var6 * q + var5) * p + i1].f();
                    n[(var6 * q + var5) * p + i1] = o[(var6 * q + var5) * p + i1];
                    m.add(o[(var6 * q + var5) * p + i1]);
                    var2 += 3;
                }

            }

        }

        if(k != null)
        {
            jm var7 = t.h;
            if(var7 != null)
            {
                b(gz.b(var7.aJ), gz.b(var7.aK), gz.b(var7.aL));
                Arrays.sort(n, new hu(var7));
            }
        }
        I = 2;
    }

    public void a(bb bb1, ui var2, float var3)
    {
        if(I > 0)
        {
            I--;
        } else
        {
            jf.a.a(k, l, t.p, t.h, var3);
            ps.a.a(k, l, t.p, t.h, t.y, var3);
            J = 0;
            K = 0;
            L = 0;
            jm var4 = t.h;
            ps.b = var4.bh + (var4.aJ - var4.bh) * (double)var3;
            ps.c = var4.bi + (var4.aK - var4.bi) * (double)var3;
            ps.d = var4.bj + (var4.aL - var4.bj) * (double)var3;
            jf.b = var4.bh + (var4.aJ - var4.bh) * (double)var3;
            jf.c = var4.bi + (var4.aK - var4.bi) * (double)var3;
            jf.d = var4.bj + (var4.aL - var4.bj) * (double)var3;
            List var5 = k.n();
            J = var5.size();
            for(int var6 = 0; var6 < var5.size(); var6++)
            {
                pb var7 = (pb)var5.get(var6);
                if(var7.a(bb1) && var2.a(var7.aT) && (var7 != t.h || t.y.z || t.h.M()) && k.h(gz.b(var7.aJ), gz.b(var7.aK), gz.b(var7.aL)))
                {
                    K++;
                    ps.a.a(var7, var3);
                }
            }

            for(int i1 = 0; i1 < a.size(); i1++)
                jf.a.a((ma)a.get(i1), var3);

        }
    }

    public String b()
    {
        return (new StringBuilder()).append("C: ").append(P).append("/").append(M).append(". F: ").append(N).append(", O: ").append(O).append(", E: ").append(Q).toString();
    }

    public String c()
    {
        return (new StringBuilder()).append("E: ").append(K).append("/").append(J).append(". B: ").append(L).append(", I: ").append(J - L - K).toString();
    }

    private void b(int i1, int var2, int var3)
    {
        i1 -= 8;
        var2 -= 8;
        var3 -= 8;
        B = 0x7fffffff;
        C = 0x7fffffff;
        D = 0x7fffffff;
        E = 0x80000000;
        F = 0x80000000;
        G = 0x80000000;
        int var4 = p * 16;
        int var5 = var4 / 2;
        for(int var6 = 0; var6 < p; var6++)
        {
            int var7 = var6 * 16;
            int var8 = (var7 + var5) - i1;
            if(var8 < 0)
                var8 -= var4 - 1;
            var8 /= var4;
            var7 -= var8 * var4;
            if(var7 < B)
                B = var7;
            if(var7 > E)
                E = var7;
            for(int var9 = 0; var9 < r; var9++)
            {
                int var10 = var9 * 16;
                int var11 = (var10 + var5) - var3;
                if(var11 < 0)
                    var11 -= var4 - 1;
                var11 /= var4;
                var10 -= var11 * var4;
                if(var10 < D)
                    D = var10;
                if(var10 > G)
                    G = var10;
                for(int var12 = 0; var12 < q; var12++)
                {
                    int var13 = var12 * 16;
                    if(var13 < C)
                        C = var13;
                    if(var13 > F)
                        F = var13;
                    cp var14 = o[(var9 * q + var12) * p + var6];
                    boolean var15 = var14.u;
                    var14.a(var7, var13, var10);
                    if(!var15 && var14.u)
                        m.add(var14);
                }

            }

        }

    }

    public int a(jm jm1, int var2, double var3)
    {
        for(int var5 = 0; var5 < 10; var5++)
        {
            R = (R + 1) % o.length;
            cp var6 = o[R];
            if(var6.u && !m.contains(var6))
                m.add(var6);
        }

        if(t.y.e != H)
            a();
        if(var2 == 0)
        {
            M = 0;
            N = 0;
            O = 0;
            P = 0;
            Q = 0;
        }
        double var33 = jm1.bh + (jm1.aJ - jm1.bh) * var3;
        double var7 = jm1.bi + (jm1.aK - jm1.bi) * var3;
        double var9 = jm1.bj + (jm1.aL - jm1.bj) * var3;
        double var11 = jm1.aJ - f;
        double var13 = jm1.aK - g;
        double var15 = jm1.aL - h;
        if(var11 * var11 + var13 * var13 + var15 * var15 > 16D)
        {
            f = jm1.aJ;
            g = jm1.aK;
            h = jm1.aL;
            b(gz.b(jm1.aJ), gz.b(jm1.aK), gz.b(jm1.aL));
            Arrays.sort(n, new hu(jm1));
        }
        byte var17 = 0;
        int var34;
        if(w && !t.y.g && var2 == 0)
        {
            byte var18 = 0;
            int var19 = 16;
            a(var18, var19);
            for(int var20 = var18; var20 < var19; var20++)
                n[var20].x = true;

            var34 = var17 + a(var18, var19, var2, var3);
            do
            {
                int var35 = var19;
                var19 *= 2;
                if(var19 > n.length)
                    var19 = n.length;
                GL11.glDisable(3553);
                GL11.glDisable(2896);
                GL11.glDisable(3008);
                GL11.glDisable(2912);
                GL11.glColorMask(false, false, false, false);
                GL11.glDepthMask(false);
                a(var35, var19);
                GL11.glPushMatrix();
                float var36 = 0.0F;
                float var21 = 0.0F;
                float var22 = 0.0F;
                for(int var23 = var35; var23 < var19; var23++)
                {
                    if(n[var23].e())
                    {
                        n[var23].o = false;
                        continue;
                    }
                    if(!n[var23].o)
                        n[var23].x = true;
                    if(!n[var23].o || n[var23].y)
                        continue;
                    float var24 = gz.c(n[var23].a(jm1));
                    int var25 = (int)(1.0F + var24 / 128F);
                    if(x % var25 != var23 % var25)
                        continue;
                    cp var26 = n[var23];
                    float var27 = (float)((double)var26.i - var33);
                    float var28 = (float)((double)var26.j - var7);
                    float var29 = (float)((double)var26.k - var9);
                    float var30 = var27 - var36;
                    float var31 = var28 - var21;
                    float var32 = var29 - var22;
                    if(var30 != 0.0F || var31 != 0.0F || var32 != 0.0F)
                    {
                        GL11.glTranslatef(var30, var31, var32);
                        var36 += var30;
                        var21 += var31;
                        var22 += var32;
                    }
                    ARBOcclusionQuery.glBeginQueryARB(35092, n[var23].z);
                    n[var23].d();
                    ARBOcclusionQuery.glEndQueryARB(35092);
                    n[var23].y = true;
                }

                GL11.glPopMatrix();
                GL11.glColorMask(true, true, true, true);
                GL11.glDepthMask(true);
                GL11.glEnable(3553);
                GL11.glEnable(3008);
                GL11.glEnable(2912);
                var34 += a(var35, var19, var2, var3);
            } while(var19 < n.length);
        } else
        {
            var34 = var17 + a(0, n.length, var2, var3);
        }
        return var34;
    }

    private void a(int i1, int var2)
    {
        for(int var3 = i1; var3 < var2; var3++)
        {
            if(!n[var3].y)
                continue;
            c.clear();
            ARBOcclusionQuery.glGetQueryObjectuARB(n[var3].z, 34919, c);
            if(c.get(0) != 0)
            {
                n[var3].y = false;
                c.clear();
                ARBOcclusionQuery.glGetQueryObjectuARB(n[var3].z, 34918, c);
                n[var3].x = c.get(0) != 0;
            }
        }

    }

    private int a(int i1, int lastChunk, int passNumber, double var4)
    {
        int nRendered = 0;
        chunkLists.clear();
        for(int i = i1; i < lastChunk; i++)
        {
            if(passNumber == 0)
            {
                M++;
                if(n[i].p[passNumber])
                    Q++;
                else
                if(!n[i].o)
                    N++;
                else
                if(w && !n[i].x)
                    O++;
                else
                    P++;
            }
            if(n[i].p[passNumber] || !n[i].o || !n[i].x)
                continue;
            int listN = n[i].a(passNumber);
            if(listN >= 0)
            {
                chunkLists.put(listN);
                nRendered++;
            }
        }

        chunkLists.flip();
        jm var19 = t.h;
        double var20 = var19.bh + (var19.aJ - var19.bh) * var4;
        double var10 = var19.bi + (var19.aK - var19.bi) * var4;
        double var12 = var19.bj + (var19.aL - var19.bj) * var4;
        GL11.glTranslatef((float)(-var20), (float)(-var10), (float)(-var12));
        GL11.glCallLists(chunkLists);
        GL11.glTranslatef((float)var20, (float)var10, (float)var12);
        return nRendered;
    }

    public void d()
    {
        x++;
    }

    public void a(float f1)
    {
        if(!t.e.m.c)
        {
            GL11.glDisable(3553);
            bb var2 = k.a(t.h, f1);
            float var3 = (float)var2.a;
            float var4 = (float)var2.b;
            float var5 = (float)var2.c;
            float var7;
            float var8;
            if(t.y.g)
            {
                float var6 = (var3 * 30F + var4 * 59F + var5 * 11F) / 100F;
                var7 = (var3 * 30F + var4 * 70F) / 100F;
                var8 = (var3 * 30F + var5 * 70F) / 100F;
                var3 = var6;
                var4 = var7;
                var5 = var8;
            }
            GL11.glColor3f(var3, var4, var5);
            lj var14 = lj.a;
            GL11.glDepthMask(false);
            GL11.glEnable(2912);
            GL11.glColor3f(var3, var4, var5);
            GL11.glCallList(z);
            GL11.glDisable(2912);
            GL11.glDisable(3008);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            float var15[] = k.m.b(k.b(f1), f1);
            float var11;
            if(var15 != null)
            {
                GL11.glDisable(3553);
                GL11.glShadeModel(7425);
                GL11.glPushMatrix();
                GL11.glRotatef(90F, 1.0F, 0.0F, 0.0F);
                var8 = k.b(f1);
                GL11.glRotatef(var8 <= 0.5F ? 0.0F : 180F, 0.0F, 0.0F, 1.0F);
                var14.a(6);
                var14.a(var15[0], var15[1], var15[2], var15[3]);
                var14.a(0.0D, 100D, 0.0D);
                byte var9 = 16;
                var14.a(var15[0], var15[1], var15[2], 0.0F);
                for(int var10 = 0; var10 <= var9; var10++)
                {
                    var11 = ((float)var10 * 3.141593F * 2.0F) / (float)var9;
                    float var12 = gz.a(var11);
                    float var13 = gz.b(var11);
                    var14.a(var12 * 120F, var13 * 120F, -var13 * 40F * var15[3]);
                }

                var14.a();
                GL11.glPopMatrix();
                GL11.glShadeModel(7424);
            }
            GL11.glEnable(3553);
            GL11.glBlendFunc(1, 1);
            GL11.glPushMatrix();
            var7 = 0.0F;
            var8 = 0.0F;
            float var16 = 0.0F;
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glTranslatef(var7, var8, var16);
            GL11.glRotatef(0.0F, 0.0F, 0.0F, 1.0F);
            GL11.glRotatef(k.b(f1) * 360F, 1.0F, 0.0F, 0.0F);
            float var17 = 30F;
            GL11.glBindTexture(3553, l.a("/terrain/sun.png"));
            var14.b();
            var14.a(-var17, 100D, -var17, 0.0D, 0.0D);
            var14.a(var17, 100D, -var17, 1.0D, 0.0D);
            var14.a(var17, 100D, var17, 1.0D, 1.0D);
            var14.a(-var17, 100D, var17, 0.0D, 1.0D);
            var14.a();
            var17 = 20F;
            GL11.glBindTexture(3553, l.a("/terrain/moon.png"));
            var14.b();
            var14.a(-var17, -100D, var17, 1.0D, 1.0D);
            var14.a(var17, -100D, var17, 0.0D, 1.0D);
            var14.a(var17, -100D, -var17, 0.0D, 0.0D);
            var14.a(-var17, -100D, -var17, 1.0D, 0.0D);
            var14.a();
            GL11.glDisable(3553);
            var11 = k.e(f1);
            if(var11 > 0.0F)
            {
                GL11.glColor4f(var11, var11, var11, var11);
                GL11.glCallList(y);
            }
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glDisable(3042);
            GL11.glEnable(3008);
            GL11.glEnable(2912);
            GL11.glPopMatrix();
            GL11.glColor3f(var3 * 0.2F + 0.04F, var4 * 0.2F + 0.04F, var5 * 0.6F + 0.1F);
            GL11.glDisable(3553);
            GL11.glCallList(A);
            GL11.glEnable(3553);
            GL11.glDepthMask(true);
        }
    }

    public void b(float f1)
    {
        if(!t.e.m.c)
            if(t.y.i)
            {
                c(f1);
            } else
            {
                GL11.glDisable(2884);
                float var2 = (float)(t.h.bi + (t.h.aK - t.h.bi) * (double)f1);
                byte var3 = 32;
                int var4 = 256 / var3;
                lj var5 = lj.a;
                GL11.glBindTexture(3553, l.a("/environment/clouds.png"));
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                bb var6 = k.c(f1);
                float var7 = (float)var6.a;
                float var8 = (float)var6.b;
                float var9 = (float)var6.c;
                float var10;
                if(t.y.g)
                {
                    var10 = (var7 * 30F + var8 * 59F + var9 * 11F) / 100F;
                    float var11 = (var7 * 30F + var8 * 70F) / 100F;
                    float var12 = (var7 * 30F + var9 * 70F) / 100F;
                    var7 = var10;
                    var8 = var11;
                    var9 = var12;
                }
                var10 = 0.0004882812F;
                double var22 = t.h.aG + (t.h.aJ - t.h.aG) * (double)f1 + (double)(((float)x + f1) * 0.03F);
                double var13 = t.h.aI + (t.h.aL - t.h.aI) * (double)f1;
                int var15 = gz.b(var22 / 2048D);
                int var16 = gz.b(var13 / 2048D);
                var22 -= var15 * 2048;
                var13 -= var16 * 2048;
                float var17 = (120F - var2) + 0.33F;
                float var18 = (float)(var22 * (double)var10);
                float var19 = (float)(var13 * (double)var10);
                var5.b();
                var5.a(var7, var8, var9, 0.8F);
                for(int var20 = -var3 * var4; var20 < var3 * var4; var20 += var3)
                {
                    for(int var21 = -var3 * var4; var21 < var3 * var4; var21 += var3)
                    {
                        var5.a(var20 + 0, var17, var21 + var3, (float)(var20 + 0) * var10 + var18, (float)(var21 + var3) * var10 + var19);
                        var5.a(var20 + var3, var17, var21 + var3, (float)(var20 + var3) * var10 + var18, (float)(var21 + var3) * var10 + var19);
                        var5.a(var20 + var3, var17, var21 + 0, (float)(var20 + var3) * var10 + var18, (float)(var21 + 0) * var10 + var19);
                        var5.a(var20 + 0, var17, var21 + 0, (float)(var20 + 0) * var10 + var18, (float)(var21 + 0) * var10 + var19);
                    }

                }

                var5.a();
                GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                GL11.glDisable(3042);
                GL11.glEnable(2884);
            }
    }

    public void c(float f1)
    {
        GL11.glDisable(2884);
        float var2 = (float)(t.h.bi + (t.h.aK - t.h.bi) * (double)f1);
        lj var3 = lj.a;
        float var4 = 12F;
        float var5 = 4F;
        double var6 = (t.h.aG + (t.h.aJ - t.h.aG) * (double)f1 + (double)(((float)x + f1) * 0.03F)) / (double)var4;
        double var8 = (t.h.aI + (t.h.aL - t.h.aI) * (double)f1) / (double)var4 + 0.33000001311302185D;
        float var10 = (108F - var2) + 0.33F;
        int var11 = gz.b(var6 / 2048D);
        int var12 = gz.b(var8 / 2048D);
        var6 -= var11 * 2048;
        var8 -= var12 * 2048;
        GL11.glBindTexture(3553, l.a("/environment/clouds.png"));
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        bb var13 = k.c(f1);
        float var14 = (float)var13.a;
        float var15 = (float)var13.b;
        float var16 = (float)var13.c;
        float var17;
        float var19;
        float var18;
        if(t.y.g)
        {
            var17 = (var14 * 30F + var15 * 59F + var16 * 11F) / 100F;
            var18 = (var14 * 30F + var15 * 70F) / 100F;
            var19 = (var14 * 30F + var16 * 70F) / 100F;
            var14 = var17;
            var15 = var18;
            var16 = var19;
        }
        var17 = (float)(var6 * 0.0D);
        var18 = (float)(var8 * 0.0D);
        var19 = 0.00390625F;
        var17 = (float)gz.b(var6) * var19;
        var18 = (float)gz.b(var8) * var19;
        float var20 = (float)(var6 - (double)gz.b(var6));
        float var21 = (float)(var8 - (double)gz.b(var8));
        byte var22 = 8;
        byte var23 = 3;
        float var24 = 0.0009765625F;
        GL11.glScalef(var4, 1.0F, var4);
        for(int var25 = 0; var25 < 2; var25++)
        {
            if(var25 == 0)
                GL11.glColorMask(false, false, false, false);
            else
                GL11.glColorMask(true, true, true, true);
            for(int var26 = -var23 + 1; var26 <= var23; var26++)
            {
                for(int var27 = -var23 + 1; var27 <= var23; var27++)
                {
                    var3.b();
                    float var28 = var26 * var22;
                    float var29 = var27 * var22;
                    float var30 = var28 - var20;
                    float var31 = var29 - var21;
                    if(var10 > -var5 - 1.0F)
                    {
                        var3.a(var14 * 0.7F, var15 * 0.7F, var16 * 0.7F, 0.8F);
                        var3.b(0.0F, -1F, 0.0F);
                        var3.a(var30 + 0.0F, var10 + 0.0F, var31 + (float)var22, (var28 + 0.0F) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                        var3.a(var30 + (float)var22, var10 + 0.0F, var31 + (float)var22, (var28 + (float)var22) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                        var3.a(var30 + (float)var22, var10 + 0.0F, var31 + 0.0F, (var28 + (float)var22) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                        var3.a(var30 + 0.0F, var10 + 0.0F, var31 + 0.0F, (var28 + 0.0F) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                    }
                    if(var10 <= var5 + 1.0F)
                    {
                        var3.a(var14, var15, var16, 0.8F);
                        var3.b(0.0F, 1.0F, 0.0F);
                        var3.a(var30 + 0.0F, (var10 + var5) - var24, var31 + (float)var22, (var28 + 0.0F) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                        var3.a(var30 + (float)var22, (var10 + var5) - var24, var31 + (float)var22, (var28 + (float)var22) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                        var3.a(var30 + (float)var22, (var10 + var5) - var24, var31 + 0.0F, (var28 + (float)var22) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                        var3.a(var30 + 0.0F, (var10 + var5) - var24, var31 + 0.0F, (var28 + 0.0F) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                    }
                    var3.a(var14 * 0.9F, var15 * 0.9F, var16 * 0.9F, 0.8F);
                    if(var26 > -1)
                    {
                        var3.b(-1F, 0.0F, 0.0F);
                        for(int var32 = 0; var32 < var22; var32++)
                        {
                            var3.a(var30 + (float)var32 + 0.0F, var10 + 0.0F, var31 + (float)var22, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                            var3.a(var30 + (float)var32 + 0.0F, var10 + var5, var31 + (float)var22, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                            var3.a(var30 + (float)var32 + 0.0F, var10 + var5, var31 + 0.0F, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                            var3.a(var30 + (float)var32 + 0.0F, var10 + 0.0F, var31 + 0.0F, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                        }

                    }
                    if(var26 <= 1)
                    {
                        var3.b(1.0F, 0.0F, 0.0F);
                        for(int var32 = 0; var32 < var22; var32++)
                        {
                            var3.a((var30 + (float)var32 + 1.0F) - var24, var10 + 0.0F, var31 + (float)var22, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                            var3.a((var30 + (float)var32 + 1.0F) - var24, var10 + var5, var31 + (float)var22, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + (float)var22) * var19 + var18);
                            var3.a((var30 + (float)var32 + 1.0F) - var24, var10 + var5, var31 + 0.0F, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                            var3.a((var30 + (float)var32 + 1.0F) - var24, var10 + 0.0F, var31 + 0.0F, (var28 + (float)var32 + 0.5F) * var19 + var17, (var29 + 0.0F) * var19 + var18);
                        }

                    }
                    var3.a(var14 * 0.8F, var15 * 0.8F, var16 * 0.8F, 0.8F);
                    if(var27 > -1)
                    {
                        var3.b(0.0F, 0.0F, -1F);
                        for(int var32 = 0; var32 < var22; var32++)
                        {
                            var3.a(var30 + 0.0F, var10 + var5, var31 + (float)var32 + 0.0F, (var28 + 0.0F) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                            var3.a(var30 + (float)var22, var10 + var5, var31 + (float)var32 + 0.0F, (var28 + (float)var22) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                            var3.a(var30 + (float)var22, var10 + 0.0F, var31 + (float)var32 + 0.0F, (var28 + (float)var22) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                            var3.a(var30 + 0.0F, var10 + 0.0F, var31 + (float)var32 + 0.0F, (var28 + 0.0F) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                        }

                    }
                    if(var27 <= 1)
                    {
                        var3.b(0.0F, 0.0F, 1.0F);
                        for(int var32 = 0; var32 < var22; var32++)
                        {
                            var3.a(var30 + 0.0F, var10 + var5, (var31 + (float)var32 + 1.0F) - var24, (var28 + 0.0F) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                            var3.a(var30 + (float)var22, var10 + var5, (var31 + (float)var32 + 1.0F) - var24, (var28 + (float)var22) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                            var3.a(var30 + (float)var22, var10 + 0.0F, (var31 + (float)var32 + 1.0F) - var24, (var28 + (float)var22) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                            var3.a(var30 + 0.0F, var10 + 0.0F, (var31 + (float)var32 + 1.0F) - var24, (var28 + 0.0F) * var19 + var17, (var29 + (float)var32 + 0.5F) * var19 + var18);
                        }

                    }
                    var3.a();
                }

            }

        }

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDisable(3042);
        GL11.glEnable(2884);
    }

    public boolean a(jm jm1, boolean var2)
    {
        jw var4 = new jw(jm1);
        cp var5[] = new cp[3];
        ArrayList var6 = null;
        int var7 = m.size();
        int var8 = 0;
        int var11;
label0:
        for(int var9 = 0; var9 < var7; var9++)
        {
            cp var10 = (cp)m.get(var9);
            if(!var2)
            {
                if(var10.a(jm1) > 1024F)
                {
                    for(var11 = 0; var11 < 3 && (var5[var11] == null || var4.a(var5[var11], var10) <= 0); var11++);
                    if(--var11 <= 0)
                        continue;
                    int var12 = var11;
                    do
                    {
                        if(--var12 == 0)
                        {
                            var5[var11] = var10;
                            continue label0;
                        }
                        var5[var12 - 1] = var5[var12];
                    } while(true);
                }
            } else
            if(!var10.o)
                continue;
            if(var6 == null)
                var6 = new ArrayList();
            var8++;
            var6.add(var10);
            m.set(var9, (Object)null);
        }

        if(var6 != null)
        {
            if(var6.size() > 1)
                Collections.sort(var6, var4);
            for(int i1 = var6.size() - 1; i1 >= 0; i1--)
            {
                cp var10 = (cp)var6.get(i1);
                var10.a();
                var10.u = false;
            }

        }
        int j1 = 0;
        for(int var18 = 2; var18 >= 0; var18--)
        {
            cp var19 = var5[var18];
            if(var19 == null)
                continue;
            if(!var19.o && var18 != 2)
            {
                var5[var18] = null;
                var5[0] = null;
                break;
            }
            var5[var18].a();
            var5[var18].u = false;
            j1++;
        }

        int k1 = 0;
        var11 = 0;
        for(int var12 = m.size(); k1 != var12; k1++)
        {
            cp var13 = (cp)m.get(k1);
            if(var13 == null || var13 == var5[0] || var13 == var5[1] || var13 == var5[2])
                continue;
            if(var11 != k1)
                m.set(var11, var13);
            var11++;
        }

        do
        {
            if(--k1 < var11)
                return var7 == var8 + j1;
            m.remove(k1);
        } while(true);
    }

    public void a(fm fm1, rk var2, int var3, hi var4, float var5)
    {
        lj var6 = lj.a;
        GL11.glEnable(3042);
        GL11.glEnable(3008);
        GL11.glBlendFunc(770, 1);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, (gz.a((float)System.currentTimeMillis() / 100F) * 0.2F + 0.4F) * 0.5F);
        if(var3 == 0)
        {
            if(i > 0.0F)
            {
                GL11.glBlendFunc(774, 768);
                int var7 = l.a("/terrain.png");
                GL11.glBindTexture(3553, var7);
                GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
                GL11.glPushMatrix();
                int var8 = k.a(var2.b, var2.c, var2.d);
                ra var9 = var8 <= 0 ? null : ra.m[var8];
                GL11.glDisable(3008);
                GL11.glPolygonOffset(-3F, -3F);
                GL11.glEnable(32823);
                var6.b();
                double var10 = fm1.bh + (fm1.aJ - fm1.bh) * (double)var5;
                double var12 = fm1.bi + (fm1.aK - fm1.bi) * (double)var5;
                double var14 = fm1.bj + (fm1.aL - fm1.bj) * (double)var5;
                var6.b(-var10, -var12, -var14);
                var6.c();
                if(var9 == null)
                    var9 = ra.t;
                u.a(var9, var2.b, var2.c, var2.d, 240 + (int)(i * 10F));
                var6.a();
                var6.b(0.0D, 0.0D, 0.0D);
                GL11.glPolygonOffset(0.0F, 0.0F);
                GL11.glDisable(32823);
                GL11.glEnable(3008);
                GL11.glDepthMask(true);
                GL11.glPopMatrix();
            }
        } else
        if(var4 != null)
        {
            GL11.glBlendFunc(770, 771);
            float var16 = gz.a((float)System.currentTimeMillis() / 100F) * 0.2F + 0.8F;
            GL11.glColor4f(var16, var16, var16, gz.a((float)System.currentTimeMillis() / 200F) * 0.2F + 0.5F);
            int var8 = l.a("/terrain.png");
            GL11.glBindTexture(3553, var8);
            int var17 = var2.b;
            int var18 = var2.c;
            int var11 = var2.d;
            if(var2.e == 0)
                var18--;
            if(var2.e == 1)
                var18++;
            if(var2.e == 2)
                var11--;
            if(var2.e == 3)
                var11++;
            if(var2.e == 4)
                var17--;
            if(var2.e == 5)
                var17++;
        }
        GL11.glDisable(3042);
        GL11.glDisable(3008);
    }

    public void b(fm fm1, rk var2, int var3, hi var4, float var5)
    {
        if(var3 == 0 && var2.a == hm.a)
        {
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.4F);
            GL11.glLineWidth(2.0F);
            GL11.glDisable(3553);
            GL11.glDepthMask(false);
            float var6 = 0.002F;
            int var7 = k.a(var2.b, var2.c, var2.d);
            if(var7 > 0)
            {
                ra.m[var7].a(k, var2.b, var2.c, var2.d);
                double var8 = fm1.bh + (fm1.aJ - fm1.bh) * (double)var5;
                double var10 = fm1.bi + (fm1.aK - fm1.bi) * (double)var5;
                double var12 = fm1.bj + (fm1.aL - fm1.bj) * (double)var5;
                a(ra.m[var7].f(k, var2.b, var2.c, var2.d).b(var6, var6, var6).c(-var8, -var10, -var12));
            }
            GL11.glDepthMask(true);
            GL11.glEnable(3553);
            GL11.glDisable(3042);
        }
    }

    private void a(dq dq1)
    {
        lj var2 = lj.a;
        var2.a(3);
        var2.a(dq1.a, dq1.b, dq1.c);
        var2.a(dq1.d, dq1.b, dq1.c);
        var2.a(dq1.d, dq1.b, dq1.f);
        var2.a(dq1.a, dq1.b, dq1.f);
        var2.a(dq1.a, dq1.b, dq1.c);
        var2.a();
        var2.a(3);
        var2.a(dq1.a, dq1.e, dq1.c);
        var2.a(dq1.d, dq1.e, dq1.c);
        var2.a(dq1.d, dq1.e, dq1.f);
        var2.a(dq1.a, dq1.e, dq1.f);
        var2.a(dq1.a, dq1.e, dq1.c);
        var2.a();
        var2.a(1);
        var2.a(dq1.a, dq1.b, dq1.c);
        var2.a(dq1.a, dq1.e, dq1.c);
        var2.a(dq1.d, dq1.b, dq1.c);
        var2.a(dq1.d, dq1.e, dq1.c);
        var2.a(dq1.d, dq1.b, dq1.f);
        var2.a(dq1.d, dq1.e, dq1.f);
        var2.a(dq1.a, dq1.b, dq1.f);
        var2.a(dq1.a, dq1.e, dq1.f);
        var2.a();
    }

    public void a(int i1, int var2, int var3, int var4, int var5, int var6)
    {
        int var7 = gz.a(i1, 16);
        int var8 = gz.a(var2, 16);
        int var9 = gz.a(var3, 16);
        int var10 = gz.a(var4, 16);
        int var11 = gz.a(var5, 16);
        int var12 = gz.a(var6, 16);
        for(int var13 = var7; var13 <= var10; var13++)
        {
            int var14 = var13 % p;
            if(var14 < 0)
                var14 += p;
            for(int var15 = var8; var15 <= var11; var15++)
            {
                int var16 = var15 % q;
                if(var16 < 0)
                    var16 += q;
                for(int var17 = var9; var17 <= var12; var17++)
                {
                    int var18 = var17 % r;
                    if(var18 < 0)
                        var18 += r;
                    int var19 = (var18 * q + var16) * p + var14;
                    cp var20 = o[var19];
                    if(!var20.u)
                    {
                        m.add(var20);
                        var20.f();
                    }
                }

            }

        }

    }

    public void a(int i1, int var2, int var3)
    {
        a(i1 - 1, var2 - 1, var3 - 1, i1 + 1, var2 + 1, var3 + 1);
    }

    public void b(int i1, int var2, int var3, int var4, int var5, int var6)
    {
        a(i1 - 1, var2 - 1, var3 - 1, var4 + 1, var5 + 1, var6 + 1);
    }

    public void a(ui ui1, float var2)
    {
        for(int var3 = 0; var3 < o.length; var3++)
            if(!o[var3].e() && (!o[var3].o || (var3 + j & 0xf) == 0))
                o[var3].a(ui1);

        j++;
    }

    public void a(String s1, int var2, int var3, int var4)
    {
        if(s1 != null)
            t.u.b((new StringBuilder()).append("C418 - ").append(s1).toString());
        t.A.a(s1, var2, var3, var4, 1.0F, 1.0F);
    }

    public void a(String s1, double var2, double var4, double var6, 
            float var8, float var9)
    {
        float var10 = 16F;
        if(var8 > 1.0F)
            var10 *= var8;
        if(t.h.e(var2, var4, var6) < (double)(var10 * var10))
            t.A.b(s1, (float)var2, (float)var4, (float)var6, var8, var9);
    }

    public void a(String s1, double var2, double var4, double var6, 
            double var8, double var10, double var12)
    {
        if(t == null || t.h == null || t.i == null)
            return;
        double var14 = t.h.aJ - var2;
        double var16 = t.h.aK - var4;
        double var18 = t.h.aL - var6;
        double var20 = 16D;
        if(var14 * var14 + var16 * var16 + var18 * var18 <= var20 * var20)
            if(s1.equals("bubble"))
                t.i.a(new bw(k, var2, var4, var6, var8, var10, var12));
            else
            if(s1.equals("smoke"))
                t.i.a(new ti(k, var2, var4, var6, var8, var10, var12));
            else
            if(s1.equals("note"))
                t.i.a(new classx(k, var2, var4, var6, var8, var10, var12));
            else
            if(s1.equals("portal"))
                t.i.a(new lw(k, var2, var4, var6, var8, var10, var12));
            else
            if(s1.equals("explode"))
                t.i.a(new fq(k, var2, var4, var6, var8, var10, var12));
            else
            if(s1.equals("flame"))
                t.i.a(new nn(k, var2, var4, var6, var8, var10, var12));
            else
            if(s1.equals("lava"))
                t.i.a(new ee(k, var2, var4, var6));
            else
            if(s1.equals("splash"))
                t.i.a(new pk(k, var2, var4, var6, var8, var10, var12));
            else
            if(s1.equals("largesmoke"))
                t.i.a(new ti(k, var2, var4, var6, var8, var10, var12, 2.5F));
            else
            if(s1.equals("reddust"))
                t.i.a(new gy(k, var2, var4, var6, (float)var8, (float)var10, (float)var12));
            else
            if(s1.equals("snowballpoof"))
                t.i.a(new mf(k, var2, var4, var6, fg.aB));
            else
            if(s1.equals("slime"))
                t.i.a(new mf(k, var2, var4, var6, fg.aK));
            else
            if(s1.equals("heart"))
                t.i.a(new classif(k, var2, var4, var6, var8, var10, var12));
    }

    public void a(pb pb1)
    {
        pb1.w_();
        if(pb1.bx != null)
            l.a(pb1.bx, new oi());
        if(pb1.by != null)
            l.a(pb1.by, new oi());
    }

    public void b(pb pb1)
    {
        if(pb1.bx != null)
            l.b(pb1.bx);
        if(pb1.by != null)
            l.b(pb1.by);
    }

    public void e()
    {
        for(int var1 = 0; var1 < o.length; var1++)
            if(o[var1].A && !o[var1].u)
            {
                m.add(o[var1]);
                o[var1].f();
            }

    }

    public void a(int i1, int j1, int k1, ma ma1)
    {
    }

    public List a;
    private eb k;
    private ho l;
    private List m;
    private cp n[];
    private cp o[];
    private int p;
    private int q;
    private int r;
    private int s;
    private Minecraft t;
    private ca u;
    private IntBuffer v;
    private boolean w;
    private int x;
    private int y;
    private int z;
    private int A;
    private int B;
    private int C;
    private int D;
    private int E;
    private int F;
    private int G;
    private int H;
    private int I;
    private int J;
    private int K;
    private int L;
    int b[];
    IntBuffer c;
    private int M;
    private int N;
    private int O;
    private int P;
    private int Q;
    private int R;
    private IntBuffer chunkLists;
    int d;
    int e;
    double f;
    double g;
    double h;
    public float i;
    int j;
}
