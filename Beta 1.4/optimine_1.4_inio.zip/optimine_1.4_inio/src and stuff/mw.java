// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   mh.java

import java.nio.FloatBuffer;
import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.*;
import org.lwjgl.util.glu.GLU;

public class mw
{

    public mw(Minecraft minecraft)
    {
        i = 0.0F;
        k = null;
        l = new bx();
        m = new bx();
        n = new bx();
        o = new bx();
        p_ = new bx();
        q = new bx();
        r_ = 4F;
        s = 4F;
        t = 0.0F;
        u = 0.0F;
        v = 0.0F;
        w = 0.0F;
        x = 0.0F;
        y = 0.0F;
        z = 0.0F;
        A = 0.0F;
        B = 1.0D;
        C = 0.0D;
        D = 0.0D;
        E = System.currentTimeMillis();
        F = new Random();
        b = 0;
        c = 0;
        d = ez.d(16);
        h = minecraft;
        a = new nt(minecraft);
    }

    public void a()
    {
        G = H;
        s = r_;
        u = t;
        w = v;
        y = x;
        A = z;
        if(h.h == null)
            h.h = h.g;
        float var1 = h.e.c(gz.b(h.h.aJ), gz.b(h.h.aK), gz.b(h.h.aL));
        float var2 = (float)(3 - h.y.e) / 3F;
        float var3 = var1 * (1.0F - var2) + var2;
        H += (var3 - H) * 0.1F;
        j++;
        a.a();
        if(h.M)
            d();
    }

    public void a(float f1)
    {
        if(h.h != null && h.e != null)
        {
            double var2 = h.b.b();
            h.x = h.h.a(var2, f1);
            double var4 = var2;
            bb var6 = h.h.e(f1);
            if(h.x != null)
                var4 = h.x.f.c(var6);
            if(h.b instanceof ml)
            {
                var2 = 32D;
                var4 = 32D;
            } else
            {
                if(var4 > 3D)
                    var4 = 3D;
                var2 = var4;
            }
            bb var7 = h.h.f(f1);
            bb var8 = var6.c(var7.a * var2, var7.b * var2, var7.c * var2);
            k = null;
            float var9 = 1.0F;
            List var10 = h.e.b(h.h, h.h.aT.a(var7.a * var2, var7.b * var2, var7.c * var2).b(var9, var9, var9));
            double var11 = 0.0D;
            for(int var13 = 0; var13 < var10.size(); var13++)
            {
                pb var14 = (pb)var10.get(var13);
                if(!var14.g_())
                    continue;
                float var15 = var14.e();
                dq var16 = var14.aT.b(var15, var15, var15);
                rk var17 = var16.a(var6, var8);
                if(var16.a(var6))
                {
                    if(0.0D < var11 || var11 == 0.0D)
                    {
                        k = var14;
                        var11 = 0.0D;
                    }
                    continue;
                }
                if(var17 == null)
                    continue;
                double var18 = var6.c(var17.f);
                if(var18 < var11 || var11 == 0.0D)
                {
                    k = var14;
                    var11 = var18;
                }
            }

            if(k != null && !(h.b instanceof ml))
                h.x = new rk(k);
        }
    }

    private float d(float f1)
    {
        jm var2 = h.h;
        float var3 = 70F;
        if(var2.a(jh.f))
            var3 = 60F;
        if(var2.V <= 0)
        {
            float var4 = (float)var2.aa + f1;
            var3 /= (1.0F - 500F / (var4 + 500F)) * 2.0F + 1.0F;
        }
        return var3 + y + (x - y) * f1;
    }

    private void e(float f1)
    {
        jm var2 = h.h;
        float var3 = (float)var2.X - f1;
        if(var2.V <= 0)
        {
            float var4 = (float)var2.aa + f1;
            GL11.glRotatef(40F - 8000F / (var4 + 200F), 0.0F, 0.0F, 1.0F);
        }
        if(var3 >= 0.0F)
        {
            var3 /= var2.Y;
            var3 = gz.a(var3 * var3 * var3 * var3 * 3.141593F);
            float var4 = var2.Z;
            GL11.glRotatef(-var4, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(-var3 * 14F, 0.0F, 0.0F, 1.0F);
            GL11.glRotatef(var4, 0.0F, 1.0F, 0.0F);
        }
    }

    private void f(float f1)
    {
        if(h.h instanceof fm)
        {
            fm var2 = (fm)h.h;
            float var3 = var2.bf - var2.be;
            float var4 = -(var2.bf + var3 * f1);
            float var5 = var2.k + (var2.l - var2.k) * f1;
            float var6 = var2.ac + (var2.ad - var2.ac) * f1;
            GL11.glTranslatef(gz.a(var4 * 3.141593F) * var5 * 0.5F, -Math.abs(gz.b(var4 * 3.141593F) * var5), 0.0F);
            GL11.glRotatef(gz.a(var4 * 3.141593F) * var5 * 3F, 0.0F, 0.0F, 1.0F);
            GL11.glRotatef(Math.abs(gz.b(var4 * 3.141593F - 0.2F) * var5) * 5F, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(var6, 1.0F, 0.0F, 0.0F);
        }
    }

    private void g(float f1)
    {
        jm var2 = h.h;
        float var3 = var2.bb - 1.62F;
        double var4 = var2.aG + (var2.aJ - var2.aG) * (double)f1;
        double var6 = (var2.aH + (var2.aK - var2.aH) * (double)f1) - (double)var3;
        double var8 = var2.aI + (var2.aL - var2.aI) * (double)f1;
        GL11.glRotatef(A + (z - A) * f1, 0.0F, 0.0F, 1.0F);
        if(var2.M())
        {
            var3 = (float)((double)var3 + 1.0D);
            GL11.glTranslatef(0.0F, 0.3F, 0.0F);
            if(!h.y.E)
            {
                int var10 = h.e.a(gz.b(var2.aJ), gz.b(var2.aK), gz.b(var2.aL));
                if(var10 == ra.S.bl)
                {
                    int var11 = h.e.e(gz.b(var2.aJ), gz.b(var2.aK), gz.b(var2.aL));
                    int var12 = var11 & 3;
                    GL11.glRotatef(var12 * 90, 0.0F, 1.0F, 0.0F);
                }
                GL11.glRotatef(var2.aR + (var2.aP - var2.aR) * f1 + 180F, 0.0F, -1F, 0.0F);
                GL11.glRotatef(var2.aS + (var2.aQ - var2.aS) * f1, -1F, 0.0F, 0.0F);
            }
        } else
        if(h.y.z)
        {
            double var27 = s + (r_ - s) * f1;
            if(h.y.E)
            {
                float var28 = u + (t - u) * f1;
                float var13 = w + (v - w) * f1;
                GL11.glTranslatef(0.0F, 0.0F, (float)(-var27));
                GL11.glRotatef(var13, 1.0F, 0.0F, 0.0F);
                GL11.glRotatef(var28, 0.0F, 1.0F, 0.0F);
            } else
            {
                float var28 = var2.aP;
                float var13 = var2.aQ;
                double var14 = (double)(-gz.a((var28 / 180F) * 3.141593F) * gz.b((var13 / 180F) * 3.141593F)) * var27;
                double var16 = (double)(gz.b((var28 / 180F) * 3.141593F) * gz.b((var13 / 180F) * 3.141593F)) * var27;
                double var18 = (double)(-gz.a((var13 / 180F) * 3.141593F)) * var27;
                for(int var20 = 0; var20 < 8; var20++)
                {
                    float var21 = (var20 & 1) * 2 - 1;
                    float var22 = (var20 >> 1 & 1) * 2 - 1;
                    float var23 = (var20 >> 2 & 1) * 2 - 1;
                    var21 *= 0.1F;
                    var22 *= 0.1F;
                    var23 *= 0.1F;
                    rk var24 = h.e.a(bb.b(var4 + (double)var21, var6 + (double)var22, var8 + (double)var23), bb.b((var4 - var14) + (double)var21 + (double)var23, (var6 - var18) + (double)var22, (var8 - var16) + (double)var23));
                    if(var24 == null)
                        continue;
                    double var25 = var24.f.c(bb.b(var4, var6, var8));
                    if(var25 < var27)
                        var27 = var25;
                }

                GL11.glRotatef(var2.aQ - var13, 1.0F, 0.0F, 0.0F);
                GL11.glRotatef(var2.aP - var28, 0.0F, 1.0F, 0.0F);
                GL11.glTranslatef(0.0F, 0.0F, (float)(-var27));
                GL11.glRotatef(var28 - var2.aP, 0.0F, 1.0F, 0.0F);
                GL11.glRotatef(var13 - var2.aQ, 1.0F, 0.0F, 0.0F);
            }
        } else
        {
            GL11.glTranslatef(0.0F, 0.0F, -0.1F);
        }
        if(!h.y.E)
        {
            GL11.glRotatef(var2.aS + (var2.aQ - var2.aS) * f1, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(var2.aR + (var2.aP - var2.aR) * f1 + 180F, 0.0F, 1.0F, 0.0F);
        }
        GL11.glTranslatef(0.0F, var3, 0.0F);
    }

    public void a(double d1, double var3, double var5)
    {
        B = d1;
        C = var3;
        D = var5;
    }

    public void b()
    {
        B = 1.0D;
    }

    private void a(float f1, int var2)
    {
        i = 256 >> h.y.e;
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        float var3 = 0.07F;
        if(h.y.g)
            GL11.glTranslatef((float)(-(var2 * 2 - 1)) * var3, 0.0F, 0.0F);
        if(B != 1.0D)
        {
            GL11.glTranslatef((float)C, (float)(-D), 0.0F);
            GL11.glScaled(B, B, 1.0D);
            GLU.gluPerspective(d(f1), (float)h.c / (float)h.d, 0.05F, i);
        } else
        {
            GLU.gluPerspective(d(f1), (float)h.c / (float)h.d, 0.05F, i);
        }
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        if(h.y.g)
            GL11.glTranslatef((float)(var2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
        e(f1);
        if(h.y.f)
            f(f1);
        float var4 = h.g.e + (h.g.d - h.g.e) * f1;
        if(var4 > 0.0F)
        {
            float var5 = 5F / (var4 * var4 + 5F) - var4 * 0.04F;
            var5 *= var5;
            GL11.glRotatef(var4 * var4 * 1500F, 0.0F, 1.0F, 1.0F);
            GL11.glScalef(1.0F / var5, 1.0F, 1.0F);
            GL11.glRotatef(-var4 * var4 * 1500F, 0.0F, 1.0F, 1.0F);
        }
        g(f1);
    }

    private void b(float f1, int var2)
    {
        GL11.glLoadIdentity();
        if(h.y.g)
            GL11.glTranslatef((float)(var2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
        GL11.glPushMatrix();
        e(f1);
        if(h.y.f)
            f(f1);
        if(!h.y.z && !h.h.M() && !h.y.y)
            a.a(f1);
        GL11.glPopMatrix();
        if(!h.y.z && !h.h.M())
        {
            a.b(f1);
            e(f1);
        }
        if(h.y.f)
            f(f1);
    }

    public void b(float f1)
    {
        if(!Display.isActive())
        {
            if(System.currentTimeMillis() - E > 500L)
                h.h();
        } else
        {
            E = System.currentTimeMillis();
        }
        if(h.L)
        {
            h.B.c();
            float var2 = h.y.c * 0.6F + 0.2F;
            float var3 = var2 * var2 * var2 * 8F;
            float var4 = (float)h.B.a * var3;
            float var5 = (float)h.B.b * var3;
            byte var6 = 1;
            if(h.y.d)
                var6 = -1;
            if(h.y.D)
            {
                var4 = l.a(var4, 0.05F * var3);
                var5 = m.a(var5, 0.05F * var3);
            }
            h.g.d(var4, var5 * (float)var6);
        }
        if(!h.v)
        {
            nj var7 = new nj(h.y, h.c, h.d);
            int var8 = var7.a();
            int var9 = var7.b();
            int var10 = (Mouse.getX() * var8) / h.c;
            int var11 = var9 - (Mouse.getY() * var9) / h.d - 1;
            if(h.e != null)
            {
                c(f1);
                if(!h.y.y || h.q != null)
                    h.u.a(f1, h.q != null, var10, var11);
            } else
            {
                GL11.glViewport(0, 0, h.c, h.d);
                GL11.glMatrixMode(5889);
                GL11.glLoadIdentity();
                GL11.glMatrixMode(5888);
                GL11.glLoadIdentity();
                c();
            }
            if(h.q != null)
            {
                GL11.glClear(256);
                h.q.a(var10, var11, f1);
                if(h.q != null && h.q.h != null)
                    h.q.h.a(f1);
            }
        }
    }

    public void c(float f1)
    {
        if(h.h == null)
            h.h = h.g;
        a(f1);
        jm var2 = h.h;
        classi var3 = h.f;
        cs var4 = h.i;
        double var5 = var2.bh + (var2.aJ - var2.bh) * (double)f1;
        double var7 = var2.bi + (var2.aK - var2.bi) * (double)f1;
        double var9 = var2.bj + (var2.aL - var2.bj) * (double)f1;
        bs var11 = h.e.v();
        if(var11 instanceof iu)
        {
            iu var12 = (iu)var11;
            int var13 = gz.d((int)var5) >> 4;
            int var14 = gz.d((int)var9) >> 4;
            var12.d(var13, var14);
        }
        for(int var15 = 0; var15 < 2; var15++)
        {
            if(h.y.g)
                if(var15 == 0)
                    GL11.glColorMask(false, true, true, false);
                else
                    GL11.glColorMask(true, false, false, false);
            GL11.glViewport(0, 0, h.c, h.d);
            h(f1);
            GL11.glClear(16640);
            GL11.glEnable(2884);
            a(f1, var15);
            classs.a();
            if(h.y.e < 2)
            {
                a(-1);
                var3.a(f1);
            }
            GL11.glEnable(2912);
            a(1);
            if(h.y.j)
                GL11.glShadeModel(7425);
            pf var16 = new pf();
            var16.a(var5, var7, var9);
            h.f.a(var16, f1);
            h.f.a(var2, false);
            a(0);
            GL11.glEnable(2912);
            GL11.glBindTexture(3553, h.o.a("/terrain.png"));
            classq.a();
            var3.a(var2, 0, f1);
            GL11.glShadeModel(7424);
            classq.b();
            var3.a(var2.e(f1), var16, f1);
            var4.b(var2, f1);
            classq.a();
            a(0);
            var4.a(var2, f1);
            if(h.x != null && var2.a(jh.f) && (var2 instanceof fm))
            {
                fm var17 = (fm)var2;
                GL11.glDisable(3008);
                var3.a(var17, h.x, 0, var17.f.b(), f1);
                var3.b(var17, h.x, 0, var17.f.b(), f1);
                GL11.glEnable(3008);
            }
            GL11.glBlendFunc(770, 771);
            a(0);
            GL11.glEnable(3042);
            GL11.glDisable(2884);
            GL11.glBindTexture(3553, h.o.a("/terrain.png"));
            if(h.y.i)
            {
                if(h.y.g)
                    if(var15 == 0)
                        GL11.glColorMask(false, true, true, false);
                    else
                        GL11.glColorMask(true, false, false, false);
                int var14 = var3.a(var2, 1, f1);
            } else
            {
                var3.a(var2, 1, f1);
            }
            GL11.glDepthMask(true);
            GL11.glEnable(2884);
            GL11.glDisable(3042);
            if(B == 1.0D && (var2 instanceof fm) && h.x != null && !var2.a(jh.f))
            {
                fm var17 = (fm)var2;
                GL11.glDisable(3008);
                var3.a(var17, h.x, 0, var17.f.b(), f1);
                var3.b(var17, h.x, 0, var17.f.b(), f1);
                GL11.glEnable(3008);
            }
            GL11.glDisable(2912);
            if(k == null);
            a(0);
            GL11.glEnable(2912);
            var3.b(f1);
            GL11.glDisable(2912);
            a(1);
            if(B == 1.0D)
            {
                GL11.glClear(256);
                b(f1, var15);
            }
            if(!h.y.g)
                return;
        }

        GL11.glColorMask(true, true, true, false);
    }

    private void d()
    {
        if(h.y.i)
        {
            jm var1 = h.h;
            eb var2 = h.e;
            int var3 = gz.b(var1.aJ);
            int var4 = gz.b(var1.aK);
            int var5 = gz.b(var1.aL);
            byte var6 = 16;
            for(int var7 = 0; var7 < 150; var7++)
            {
                int var8 = (var3 + F.nextInt(var6)) - F.nextInt(var6);
                int var9 = (var5 + F.nextInt(var6)) - F.nextInt(var6);
                int var10 = var2.f(var8, var9);
                int var11 = var2.a(var8, var10 - 1, var9);
                if(var10 > var4 + var6 || var10 < var4 - var6)
                    continue;
                float var12 = F.nextFloat();
                float var13 = F.nextFloat();
                if(var11 > 0)
                    h.i.a(new tb(var2, (float)var8 + var12, (double)((float)var10 + 0.1F) - ra.m[var11].bp, (float)var9 + var13));
            }

        }
    }

    public void c()
    {
        nj var1 = new nj(h.y, h.c, h.d);
     //   int var2 = var1.a();
     //   int var3 = var1.b();
        GL11.glClear(256);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0D, var1.a, var1.b, 0.0D, 1000D, 3000D);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0F, 0.0F, -2000F);
    }

    private void h(float f1)
    {
        eb var2 = h.e;
        jm var3 = h.h;
        float var4 = 1.0F / (float)(4 - h.y.e);
        var4 = 1.0F - (float)Math.pow(var4, 0.25D);
        bb var5 = var2.a(h.h, f1);
        float var6 = (float)var5.a;
        float var7 = (float)var5.b;
        float var8 = (float)var5.c;
        bb var9 = var2.d(f1);
        e = (float)var9.a;
        f = (float)var9.b;
        g = (float)var9.c;
        e += (var6 - e) * var4;
        f += (var7 - f) * var4;
        g += (var8 - g) * var4;
        if(var3.a(jh.f))
        {
            e = 0.02F;
            f = 0.02F;
            g = 0.2F;
        } else
        if(var3.a(jh.g))
        {
            e = 0.6F;
            f = 0.1F;
            g = 0.0F;
        }
        float var10 = G + (H - G) * f1;
        e *= var10;
        f *= var10;
        g *= var10;
        if(h.y.g)
        {
            float var11 = (e * 30F + f * 59F + g * 11F) / 100F;
            float var12 = (e * 30F + f * 70F) / 100F;
            float var13 = (e * 30F + g * 70F) / 100F;
            e = var11;
            f = var12;
            g = var13;
        }
        GL11.glClearColor(e, f, g, 0.0F);
    }

    private void a(int i1)
    {
        jm var2 = h.h;
        GL11.glFog(2918, a(e, f, g, 1.0F));
        GL11.glNormal3f(0.0F, -1F, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        if(var2.a(jh.f))
        {
            GL11.glFogi(2917, 2048);
            GL11.glFogf(2914, 0.1F);
            float var3 = 0.4F;
            float var4 = 0.4F;
            float var5 = 0.9F;
            if(h.y.g)
            {
                float var6 = (var3 * 30F + var4 * 59F + var5 * 11F) / 100F;
                float var7 = (var3 * 30F + var4 * 70F) / 100F;
                float var8 = (var3 * 30F + var5 * 70F) / 100F;
            }
        } else
        if(var2.a(jh.g))
        {
            GL11.glFogi(2917, 2048);
            GL11.glFogf(2914, 2.0F);
            float var3 = 0.4F;
            float var4 = 0.3F;
            float var5 = 0.3F;
            if(h.y.g)
            {
                float var6 = (var3 * 30F + var4 * 59F + var5 * 11F) / 100F;
                float var7 = (var3 * 30F + var4 * 70F) / 100F;
                float var8 = (var3 * 30F + var5 * 70F) / 100F;
            }
        } else
        {
            GL11.glFogi(2917, 9729);
            GL11.glFogf(2915, i * 0.25F);
            GL11.glFogf(2916, i);
            if(i1 < 0)
            {
                GL11.glFogf(2915, 0.0F);
                GL11.glFogf(2916, i * 0.8F);
            }
            if(GLContext.getCapabilities().GL_NV_fog_distance)
                GL11.glFogi(34138, 34139);
            if(h.e.m.c)
                GL11.glFogf(2915, 0.0F);
        }
        GL11.glEnable(2903);
        GL11.glColorMaterial(1028, 4608);
    }

    private FloatBuffer a(float f1, float var2, float var3, float var4)
    {
        d.clear();
        d.put(f1).put(var2).put(var3).put(var4);
        d.flip();
        return d;
    }

    private Minecraft h;
    private float i;
    public nt a;
    private int j;
    private pb k;
    private bx l;
    private bx m;
    private bx n;
    private bx o;
    private bx p_;
    private bx q;
    private float r_;
    private float s;
    private float t;
    private float u;
    private float v;
    private float w;
    private float x;
    private float y;
    private float z;
    private float A;
    private double B;
    private double C;
    private double D;
    private long E;
    private Random F;
    volatile int b;
    volatile int c;
    FloatBuffer d;
    float e;
    float f;
    float g;
    private float G;
    private float H;
}
