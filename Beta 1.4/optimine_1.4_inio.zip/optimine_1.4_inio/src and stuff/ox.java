// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   oi.java

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Formatter;
import java.util.Random;
import javax.imageio.ImageIO;
import org.lwjgl.opengl.GL11;

public class ox
{

    public ox(is is1, String fileName, ho tex)
    {
        colors = new int[32];
        basicWidth = new byte[256];
        unicodeWidth = new byte[0x10000];
        r = new Random();
        this.tex = tex;
        try
        {
            Class modloader = Class.forName("ModLoader");
            if(modloader != null)
            {
                Method runMethod = modloader.getDeclaredMethod("RegisterAllTextureOverrides", new Class[] {
                    ho.class
                });
                runMethod.invoke(null, new Object[] {
                    tex
                });
            }
        }
        catch(Throwable e) { }
        BufferedImage image;
        try
        {
            image = ImageIO.read(hb.class.getResourceAsStream(fileName));
            InputStream uniWidthFile = hb.class.getResourceAsStream("/font/glyph_sizes.bin");
            if(uniWidthFile != null)
                uniWidthFile.read(unicodeWidth);
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
        int width = image.getWidth();
        int height = image.getHeight();
        int imageARGB[] = new int[width * height];
        image.getRGB(0, 0, width, height, imageARGB, 0, width);
        for(int n = 0; n < 256; n++)
        {
            int col = n % 16;
            int row = n / 16;
            int glyphWidth = 7;
            do
            {
                if(glyphWidth < 0)
                    break;
                int xOff = col * 8 + glyphWidth;
                boolean emptyRow = true;
                for(int y = 0; y < 8 && emptyRow; y++)
                {
                    int pixel = imageARGB[xOff + (row * 8 + y) * width] & 0xff;
                    if(pixel > 0)
                        emptyRow = false;
                }

                if(!emptyRow)
                    break;
                glyphWidth--;
            } while(true);
            if(n == 32)
                glyphWidth = 2;
            basicWidth[n] = (byte)(glyphWidth + 2);
        }

        basicTexID = tex.a(image);
        for(int colorN = 0; colorN < 32; colorN++)
        {
            int var10 = (colorN >> 3 & 1) * 85;
            int red = (colorN >> 2 & 1) * 170 + var10;
            int green = (colorN >> 1 & 1) * 170 + var10;
            int blue = (colorN >> 0 & 1) * 170 + var10;
            if(colorN == 6)
                red += 85;
            if(is1.g)
            {
                int tmpRed = (red * 30 + green * 59 + blue * 11) / 100;
                int tmpGreen = (red * 30 + green * 70) / 100;
                int tmpBlue = (red * 30 + blue * 70) / 100;
                red = tmpRed;
                green = tmpGreen;
                blue = tmpBlue;
            }
            if(colorN >= 16)
            {
                red /= 4;
                green /= 4;
                blue /= 4;
            }
            colors[colorN] = (red & 0xff) << 16 | (green & 0xff) << 8 | blue & 0xff;
        }

    }

    private void renderBasicCharacter(int i)
    {
        float xOff = (i % 16) * 8;
        float yOff = (i / 16) * 8;
        if(lastBoundTexID != basicTexID)
        {
            GL11.glBindTexture(3553, basicTexID);
            lastBoundTexID = basicTexID;
        }
        float width = (float)basicWidth[i] - 0.01F;
        GL11.glBegin(5);
        GL11.glTexCoord2f(xOff / 128F, yOff / 128F);
        GL11.glVertex3f(xPos, yPos, 0.0F);
        GL11.glTexCoord2f(xOff / 128F, (yOff + 7.99F) / 128F);
        GL11.glVertex3f(xPos, yPos + 7.99F, 0.0F);
        GL11.glTexCoord2f((xOff + width) / 128F, yOff / 128F);
        GL11.glVertex3f(xPos + width, yPos, 0.0F);
        GL11.glTexCoord2f((xOff + width) / 128F, (yOff + 7.99F) / 128F);
        GL11.glVertex3f(xPos + width, yPos + 7.99F, 0.0F);
        GL11.glEnd();
        xPos += basicWidth[i];
    }

    private void loadUnicodePage(int i)
    {
        StringBuilder fileName = new StringBuilder();
        (new Formatter(fileName)).format("/font/glyph_%02X.png", new Object[] {
            Integer.valueOf(i)
        });
        BufferedImage image;
        try
        {
            image = ImageIO.read(gn.class.getResourceAsStream(fileName.toString()));
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
        unicodeTexID[i] = tex.a(image);
        lastBoundTexID = unicodeTexID[i];
    }

    private String randomString(int i)
    {
        char text[] = new char[i];
        while(i-- != 0) 
        {
            int rand = r.nextInt() & 0xf;
            if(rand == 0)
                text[i] = '\247';
            else
                text[i] = (char)(48 + rand);
        }
        return new String(text);
    }

    private void renderUnicodeCharacter(char c1)
    {
        if(unicodeWidth[c1] == 0)
            return;
        int page = c1 / 256;
        if(unicodeTexID[page] == 0)
            loadUnicodePage(page);
        if(lastBoundTexID != unicodeTexID[page])
        {
            GL11.glBindTexture(3553, unicodeTexID[page]);
            lastBoundTexID = unicodeTexID[page];
        }
        int firstLeft = unicodeWidth[c1] >> 4;
        int firstRight = unicodeWidth[c1] & 0xf;
        float left;
        float right;
        if(firstRight > 7)
        {
            right = 16F;
            left = 0.0F;
        } else
        {
            right = firstRight + 1;
            left = firstLeft;
        }
        float xOff = (float)((c1 % 16) * 16) + left;
        float yOff = ((c1 & 0xff) / 16) * 16;
        float width = right - left - 0.02F;
        GL11.glBegin(5);
        GL11.glTexCoord2f(xOff / 256F, yOff / 256F);
        GL11.glVertex3f(xPos, yPos, 0.0F);
        GL11.glTexCoord2f(xOff / 256F, (yOff + 15.98F) / 256F);
        GL11.glVertex3f(xPos, yPos + 7.99F, 0.0F);
        GL11.glTexCoord2f((xOff + width) / 256F, yOff / 256F);
        GL11.glVertex3f(xPos + width / 2.0F, yPos, 0.0F);
        GL11.glTexCoord2f((xOff + width) / 256F, (yOff + 15.98F) / 256F);
        GL11.glVertex3f(xPos + width / 2.0F, yPos + 7.99F, 0.0F);
        GL11.glEnd();
        xPos += (right - left) / 2.0F + 1.0F;
    }

    private void renderString(String s, boolean dropShadow)
    {
        for(int i = 0; i < s.length(); i++)
        {
            char c = s.charAt(i);
            if(c == '\247' && i + 1 < s.length())
            {
                int colorN = "0123456789abcdef".indexOf(s.toLowerCase().charAt(i + 1));
                if(colorN < 0 || colorN > 15)
                    colorN = 15;
                if(dropShadow)
                    colorN += 16;
                int color = colors[colorN];
                GL11.glColor3f((float)(color >> 16) / 255F, (float)(color >> 8 & 0xff) / 255F, (float)(color & 0xff) / 255F);
                i++;
                continue;
            }
            int index = em.a.indexOf(c);
            if(c == ' ')
            {
                xPos += 4F;
                continue;
            }
            if(index > 0)
                renderBasicCharacter(index + 32);
            else
                renderUnicodeCharacter(c);
        }

    }

    private void renderString(String s, int x, int y, int color, boolean dropShadow)
    {
        if(s != null)
        {
            lastBoundTexID = 0;
            if((color & 0xff000000) == 0)
                color |= 0xff000000;
            if(dropShadow)
                color = (color & 0xfcfcfc) >> 2 | color & 0xff000000;
            GL11.glColor4f((float)(color >> 16 & 0xff) / 255F, (float)(color >> 8 & 0xff) / 255F, (float)(color & 0xff) / 255F, (float)(color >> 24 & 0xff) / 255F);
            xPos = x;
            yPos = y;
            renderString(s, dropShadow);
        }
    }

    public void a(String s, int x, int y, int color)
    {
        renderString(s, x + 1, y + 1, color, true);
        renderString(s, x, y, color, false);
    }

    public void b(String s, int x, int y, int color)
    {
        renderString(s, x, y, color, false);
    }

    public int a(String s)
    {
        if(s == null)
            return 0;
        int len = 0;
        for(int i = 0; i < s.length(); i++)
        {
            char c = s.charAt(i);
            if(c == '\247')
            {
                i++;
                continue;
            }
            int charindex = em.a.indexOf(c);
            if(charindex >= 0)
            {
                len += basicWidth[charindex + 32];
                continue;
            }
            if(unicodeWidth[c] == 0)
                continue;
            int left = unicodeWidth[c] >> 4;
            int right = unicodeWidth[c] & 0xf;
            if(right > 7)
            {
                right = 15;
                left = 0;
            }
            right++;
            len += (right - left) / 2 + 1;
        }

        return len;
    }
    
    public void a(String s, int i, int j, int k, int l)
    {
        String as[] = s.split(" ");
        for(int i1 = 0; i1 < as.length;)
        {
            String s1;
            for(s1 = (new StringBuilder()).append(as[i1++]).append(" ").toString(); i1 < as.length && a((new StringBuilder()).append(s1).append(as[i1]).toString()) < k; s1 = (new StringBuilder()).append(s1).append(as[i1++]).append(" ").toString());
            b(s1, i, j, l);
            j += 8;
        }

    }

    private int colors[];
    private byte basicWidth[];
    private byte unicodeWidth[];
    private final int unicodeTexID[] = new int[256];
    private final int basicTexID;
    private int lastBoundTexID;
    private ho tex;
    private float xPos;
    private float yPos;
    private Random r;
}
